import com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar
import net.fabricmc.loom.task.RemapJarTask

plugins {
    id("me.decce.gnetum.gradle.gnetum-common-conventions")
    id("net.fabricmc.fabric-loom-remap") version "1.17-SNAPSHOT"
    id("com.gradleup.shadow")
    id("me.modmuss50.mod-publish-plugin")
}

fun prop(name: String) = if (hasProperty(name)) findProperty(name) as String else throw IllegalArgumentException("$name not found")

dependencies {
    minecraft("com.mojang:minecraft:${prop("deps.minecraft")}")
    mappings(loom.officialMojangMappings())
    modImplementation("net.fabricmc:fabric-loader:0.18.4")
    modImplementation("net.fabricmc.fabric-api:fabric-api:${prop("deps.fabric_api")}")

    if (hasProperty("deps.sodium")) {
        modCompileOnly("${prop("deps.sodium")}")
    }
    if (hasProperty("deps.sodium_legacy")) {
        modCompileOnly("${prop("deps.sodium_legacy")}")
    }
    if (hasProperty("deps.jade")) {
        modCompileOnly("maven.modrinth:jade:${prop("deps.jade")}")
    }
    if (hasProperty("deps.xaerominimap")) {
        modCompileOnly("maven.modrinth:xaeros-minimap:${prop("deps.xaerominimap")}")
    }
    if (hasProperty("deps.journeymap")) {
        modCompileOnly("maven.modrinth:journeymap:${prop("deps.journeymap")}")
    }
    if (hasProperty("deps.immediatelyfast")) {
        modCompileOnly("maven.modrinth:immediatelyfast:${prop("deps.immediatelyfast")}")
    }
}

tasks {
    named<Jar>("jar") {
        archiveClassifier = "slim"
    }

    named<ShadowJar>("shadowJar") {
        // On 1.21.4, the game throws an error due to nonexistent shader include even if we don't use the shaders
        // We exclude the shaders files to prevent issues, as well as reduce the jar size by a bit
        if (stonecutter.eval(stonecutter.current.version, "<=1.21.4")) {
            exclude("assets/gnetum/shaders/**")
        }
    }

    named<RemapJarTask>("remapJar") {
        dependsOn(shadowJar)
        inputFile = shadowJar.flatMap { it.archiveFile }
        archiveClassifier = ""
    }

    register<Copy>("buildAndCollect") {
        group = "build"
        dependsOn(remapJar)
        from(remapJar.flatMap { it.archiveFile })
        into(rootProject.layout.buildDirectory.dir("libs"))
    }
}

publishMods {
    file = tasks.remapJar.get().archiveFile
}